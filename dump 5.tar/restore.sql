--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.5
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE motherparkers_user;
--
-- Name: motherparkers_user; Type: DATABASE; Schema: -; Owner: motherparkers_user
--

CREATE DATABASE motherparkers_user WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE motherparkers_user OWNER TO motherparkers_user;

\connect motherparkers_user

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analytics_mlmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_mlmodel (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    version character varying(50) NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.analytics_mlmodel OWNER TO postgres;

--
-- Name: analytics_mlmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_mlmodel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_mlmodel_id_seq OWNER TO postgres;

--
-- Name: analytics_mlmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_mlmodel_id_seq OWNED BY public.analytics_mlmodel.id;


--
-- Name: analytics_mlmodelresult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_mlmodelresult (
    id bigint NOT NULL,
    result_data jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    run_id bigint NOT NULL
);


ALTER TABLE public.analytics_mlmodelresult OWNER TO postgres;

--
-- Name: analytics_mlmodelresult_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_mlmodelresult_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_mlmodelresult_id_seq OWNER TO postgres;

--
-- Name: analytics_mlmodelresult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_mlmodelresult_id_seq OWNED BY public.analytics_mlmodelresult.id;


--
-- Name: analytics_mlmodelrun; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.analytics_mlmodelrun (
    id bigint NOT NULL,
    run_date timestamp with time zone NOT NULL,
    parameters jsonb NOT NULL,
    status character varying(50) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.analytics_mlmodelrun OWNER TO postgres;

--
-- Name: analytics_mlmodelrun_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.analytics_mlmodelrun_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analytics_mlmodelrun_id_seq OWNER TO postgres;

--
-- Name: analytics_mlmodelrun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.analytics_mlmodelrun_id_seq OWNED BY public.analytics_mlmodelrun.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: core_userprofile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_userprofile (
    id bigint NOT NULL,
    role character varying(20) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.core_userprofile OWNER TO postgres;

--
-- Name: core_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.core_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.core_userprofile_id_seq OWNER TO postgres;

--
-- Name: core_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.core_userprofile_id_seq OWNED BY public.core_userprofile.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_celery_beat_clockedschedule; Type: TABLE; Schema: public; Owner: motherparkers_user
--

CREATE TABLE public.django_celery_beat_clockedschedule (
    id integer NOT NULL,
    clocked_time timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_clockedschedule OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: motherparkers_user
--

CREATE SEQUENCE public.django_celery_beat_clockedschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.django_celery_beat_clockedschedule_id_seq OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: motherparkers_user
--

ALTER SEQUENCE public.django_celery_beat_clockedschedule_id_seq OWNED BY public.django_celery_beat_clockedschedule.id;


--
-- Name: django_celery_beat_crontabschedule; Type: TABLE; Schema: public; Owner: motherparkers_user
--

CREATE TABLE public.django_celery_beat_crontabschedule (
    id integer NOT NULL,
    minute character varying(240) NOT NULL,
    hour character varying(96) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(124) NOT NULL,
    month_of_year character varying(64) NOT NULL,
    timezone character varying(63) NOT NULL
);


ALTER TABLE public.django_celery_beat_crontabschedule OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: motherparkers_user
--

CREATE SEQUENCE public.django_celery_beat_crontabschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.django_celery_beat_crontabschedule_id_seq OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: motherparkers_user
--

ALTER SEQUENCE public.django_celery_beat_crontabschedule_id_seq OWNED BY public.django_celery_beat_crontabschedule.id;


--
-- Name: django_celery_beat_intervalschedule; Type: TABLE; Schema: public; Owner: motherparkers_user
--

CREATE TABLE public.django_celery_beat_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


ALTER TABLE public.django_celery_beat_intervalschedule OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: motherparkers_user
--

CREATE SEQUENCE public.django_celery_beat_intervalschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.django_celery_beat_intervalschedule_id_seq OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: motherparkers_user
--

ALTER SEQUENCE public.django_celery_beat_intervalschedule_id_seq OWNED BY public.django_celery_beat_intervalschedule.id;


--
-- Name: django_celery_beat_periodictask; Type: TABLE; Schema: public; Owner: motherparkers_user
--

CREATE TABLE public.django_celery_beat_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    crontab_id integer,
    interval_id integer,
    solar_id integer,
    one_off boolean NOT NULL,
    start_time timestamp with time zone,
    priority integer,
    headers text NOT NULL,
    clocked_id integer,
    expire_seconds integer,
    CONSTRAINT django_celery_beat_periodictask_expire_seconds_check CHECK ((expire_seconds >= 0)),
    CONSTRAINT django_celery_beat_periodictask_priority_check CHECK ((priority >= 0)),
    CONSTRAINT django_celery_beat_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


ALTER TABLE public.django_celery_beat_periodictask OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: motherparkers_user
--

CREATE SEQUENCE public.django_celery_beat_periodictask_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.django_celery_beat_periodictask_id_seq OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: motherparkers_user
--

ALTER SEQUENCE public.django_celery_beat_periodictask_id_seq OWNED BY public.django_celery_beat_periodictask.id;


--
-- Name: django_celery_beat_periodictasks; Type: TABLE; Schema: public; Owner: motherparkers_user
--

CREATE TABLE public.django_celery_beat_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_periodictasks OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_solarschedule; Type: TABLE; Schema: public; Owner: motherparkers_user
--

CREATE TABLE public.django_celery_beat_solarschedule (
    id integer NOT NULL,
    event character varying(24) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL
);


ALTER TABLE public.django_celery_beat_solarschedule OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: motherparkers_user
--

CREATE SEQUENCE public.django_celery_beat_solarschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.django_celery_beat_solarschedule_id_seq OWNER TO motherparkers_user;

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: motherparkers_user
--

ALTER SEQUENCE public.django_celery_beat_solarschedule_id_seq OWNED BY public.django_celery_beat_solarschedule.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: procurement_auditreport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_auditreport (
    id bigint NOT NULL,
    audit_date date NOT NULL,
    report_summary text NOT NULL,
    compliance_status character varying(50) NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_auditreport OWNER TO postgres;

--
-- Name: procurement_auditreport_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_auditreport_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_auditreport_id_seq OWNER TO postgres;

--
-- Name: procurement_auditreport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_auditreport_id_seq OWNED BY public.procurement_auditreport.id;


--
-- Name: procurement_certification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_certification (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    issuing_body character varying(100) NOT NULL
);


ALTER TABLE public.procurement_certification OWNER TO postgres;

--
-- Name: procurement_certification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_certification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_certification_id_seq OWNER TO postgres;

--
-- Name: procurement_certification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_certification_id_seq OWNED BY public.procurement_certification.id;


--
-- Name: procurement_commodity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_commodity (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    type character varying(100) NOT NULL,
    unit_of_measure character varying(50) NOT NULL
);


ALTER TABLE public.procurement_commodity OWNER TO postgres;

--
-- Name: procurement_commodity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_commodity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_commodity_id_seq OWNER TO postgres;

--
-- Name: procurement_commodity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_commodity_id_seq OWNED BY public.procurement_commodity.id;


--
-- Name: procurement_commoditynews; Type: TABLE; Schema: public; Owner: motherparkers_user
--

CREATE TABLE public.procurement_commoditynews (
    id bigint NOT NULL,
    article_data jsonb NOT NULL,
    fetch_date jsonb,
    time_range_start jsonb,
    time_range_end jsonb,
    coffee_commodity_price_fluctuation jsonb NOT NULL,
    coffee_geopolitical_tensions jsonb NOT NULL,
    coffee_logistics_delays jsonb NOT NULL,
    coffee_shipping_costs jsonb NOT NULL,
    coffee_freight_rates jsonb NOT NULL,
    coffee_natural_disasters jsonb NOT NULL,
    coffee_labor_strikes jsonb NOT NULL,
    coffee_market_shortage jsonb NOT NULL,
    coffee_procurement_fraud jsonb NOT NULL,
    coffee_supplier_risk jsonb NOT NULL,
    coffee_global_demand_shift jsonb NOT NULL,
    coffee_manufacturing_slowdown jsonb NOT NULL,
    coffee_regulatory_changes jsonb NOT NULL,
    commodity_id bigint NOT NULL
);


ALTER TABLE public.procurement_commoditynews OWNER TO motherparkers_user;

--
-- Name: procurement_commoditynews_id_seq; Type: SEQUENCE; Schema: public; Owner: motherparkers_user
--

CREATE SEQUENCE public.procurement_commoditynews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_commoditynews_id_seq OWNER TO motherparkers_user;

--
-- Name: procurement_commoditynews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: motherparkers_user
--

ALTER SEQUENCE public.procurement_commoditynews_id_seq OWNED BY public.procurement_commoditynews.id;


--
-- Name: procurement_commodityprice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_commodityprice (
    id bigint NOT NULL,
    date date NOT NULL,
    price numeric(12,4) NOT NULL,
    source_api character varying(100) NOT NULL,
    currency character varying(10) NOT NULL,
    commodity_id bigint NOT NULL
);


ALTER TABLE public.procurement_commodityprice OWNER TO postgres;

--
-- Name: procurement_commodityprice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_commodityprice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_commodityprice_id_seq OWNER TO postgres;

--
-- Name: procurement_commodityprice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_commodityprice_id_seq OWNED BY public.procurement_commodityprice.id;


--
-- Name: procurement_expensecategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_expensecategory (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL,
    parent_category_id bigint
);


ALTER TABLE public.procurement_expensecategory OWNER TO postgres;

--
-- Name: procurement_expensecategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_expensecategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_expensecategory_id_seq OWNER TO postgres;

--
-- Name: procurement_expensecategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_expensecategory_id_seq OWNED BY public.procurement_expensecategory.id;


--
-- Name: procurement_inventorylevel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_inventorylevel (
    id bigint NOT NULL,
    warehouse character varying(100) NOT NULL,
    quantity double precision NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    raw_material_id bigint NOT NULL
);


ALTER TABLE public.procurement_inventorylevel OWNER TO postgres;

--
-- Name: procurement_inventorylevel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_inventorylevel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_inventorylevel_id_seq OWNER TO postgres;

--
-- Name: procurement_inventorylevel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_inventorylevel_id_seq OWNED BY public.procurement_inventorylevel.id;


--
-- Name: procurement_invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_invoice (
    id bigint NOT NULL,
    invoice_number character varying(100) NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    issue_date date NOT NULL,
    due_date date NOT NULL,
    status character varying(50) NOT NULL,
    po_id bigint NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_invoice OWNER TO postgres;

--
-- Name: procurement_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_invoice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_invoice_id_seq OWNER TO postgres;

--
-- Name: procurement_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_invoice_id_seq OWNED BY public.procurement_invoice.id;


--
-- Name: procurement_materialforecast; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_materialforecast (
    id bigint NOT NULL,
    forecast_date date NOT NULL,
    predicted_demand_qty double precision NOT NULL,
    model_version character varying(50) NOT NULL,
    raw_material_id bigint NOT NULL
);


ALTER TABLE public.procurement_materialforecast OWNER TO postgres;

--
-- Name: procurement_materialforecast_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_materialforecast_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_materialforecast_id_seq OWNER TO postgres;

--
-- Name: procurement_materialforecast_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_materialforecast_id_seq OWNED BY public.procurement_materialforecast.id;


--
-- Name: procurement_priceprediction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_priceprediction (
    id bigint NOT NULL,
    prediction_date date NOT NULL,
    predicted_price numeric(12,4) NOT NULL,
    model_version character varying(50) NOT NULL,
    confidence_score double precision NOT NULL,
    commodity_id bigint NOT NULL
);


ALTER TABLE public.procurement_priceprediction OWNER TO postgres;

--
-- Name: procurement_priceprediction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_priceprediction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_priceprediction_id_seq OWNER TO postgres;

--
-- Name: procurement_priceprediction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_priceprediction_id_seq OWNED BY public.procurement_priceprediction.id;


--
-- Name: procurement_procurementnewssummary; Type: TABLE; Schema: public; Owner: motherparkers_user
--

CREATE TABLE public.procurement_procurementnewssummary (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    result_json jsonb NOT NULL
);


ALTER TABLE public.procurement_procurementnewssummary OWNER TO motherparkers_user;

--
-- Name: procurement_procurementnewssummary_id_seq; Type: SEQUENCE; Schema: public; Owner: motherparkers_user
--

CREATE SEQUENCE public.procurement_procurementnewssummary_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_procurementnewssummary_id_seq OWNER TO motherparkers_user;

--
-- Name: procurement_procurementnewssummary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: motherparkers_user
--

ALTER SEQUENCE public.procurement_procurementnewssummary_id_seq OWNED BY public.procurement_procurementnewssummary.id;


--
-- Name: procurement_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_product (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    sku character varying(50) NOT NULL,
    unit_of_sale character varying(50) NOT NULL
);


ALTER TABLE public.procurement_product OWNER TO postgres;

--
-- Name: procurement_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_product_id_seq OWNER TO postgres;

--
-- Name: procurement_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_product_id_seq OWNED BY public.procurement_product.id;


--
-- Name: procurement_productcomponent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_productcomponent (
    id bigint NOT NULL,
    quantity_needed double precision NOT NULL,
    product_id bigint NOT NULL,
    raw_material_id bigint NOT NULL
);


ALTER TABLE public.procurement_productcomponent OWNER TO postgres;

--
-- Name: procurement_productcomponent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_productcomponent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_productcomponent_id_seq OWNER TO postgres;

--
-- Name: procurement_productcomponent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_productcomponent_id_seq OWNED BY public.procurement_productcomponent.id;


--
-- Name: procurement_purchaseorder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_purchaseorder (
    id bigint NOT NULL,
    po_number character varying(50) NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    order_date date NOT NULL,
    status character varying(50) NOT NULL,
    currency character varying(10) NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_purchaseorder OWNER TO postgres;

--
-- Name: procurement_purchaseorder_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_purchaseorder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_purchaseorder_id_seq OWNER TO postgres;

--
-- Name: procurement_purchaseorder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_purchaseorder_id_seq OWNED BY public.procurement_purchaseorder.id;


--
-- Name: procurement_purchaseorderitem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_purchaseorderitem (
    id bigint NOT NULL,
    quantity double precision NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    line_total numeric(12,2) NOT NULL,
    po_id bigint NOT NULL,
    raw_material_id bigint NOT NULL
);


ALTER TABLE public.procurement_purchaseorderitem OWNER TO postgres;

--
-- Name: procurement_purchaseorderitem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_purchaseorderitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_purchaseorderitem_id_seq OWNER TO postgres;

--
-- Name: procurement_purchaseorderitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_purchaseorderitem_id_seq OWNED BY public.procurement_purchaseorderitem.id;


--
-- Name: procurement_rawmaterial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_rawmaterial (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    unit_of_measure character varying(50) NOT NULL,
    min_stock_level double precision NOT NULL,
    max_stock_level double precision NOT NULL
);


ALTER TABLE public.procurement_rawmaterial OWNER TO postgres;

--
-- Name: procurement_rawmaterial_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_rawmaterial_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_rawmaterial_id_seq OWNER TO postgres;

--
-- Name: procurement_rawmaterial_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_rawmaterial_id_seq OWNED BY public.procurement_rawmaterial.id;


--
-- Name: procurement_riskevent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_riskevent (
    id bigint NOT NULL,
    description text NOT NULL,
    severity character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    event_date date NOT NULL,
    source_data text NOT NULL,
    region_id bigint NOT NULL,
    risk_type_id bigint NOT NULL
);


ALTER TABLE public.procurement_riskevent OWNER TO postgres;

--
-- Name: procurement_riskevent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_riskevent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_riskevent_id_seq OWNER TO postgres;

--
-- Name: procurement_riskevent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_riskevent_id_seq OWNED BY public.procurement_riskevent.id;


--
-- Name: procurement_riskevent_impacted_commodities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_riskevent_impacted_commodities (
    id bigint NOT NULL,
    riskevent_id bigint NOT NULL,
    commodity_id bigint NOT NULL
);


ALTER TABLE public.procurement_riskevent_impacted_commodities OWNER TO postgres;

--
-- Name: procurement_riskevent_impacted_commodities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_riskevent_impacted_commodities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_riskevent_impacted_commodities_id_seq OWNER TO postgres;

--
-- Name: procurement_riskevent_impacted_commodities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_riskevent_impacted_commodities_id_seq OWNED BY public.procurement_riskevent_impacted_commodities.id;


--
-- Name: procurement_risktype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_risktype (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.procurement_risktype OWNER TO postgres;

--
-- Name: procurement_risktype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_risktype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_risktype_id_seq OWNER TO postgres;

--
-- Name: procurement_risktype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_risktype_id_seq OWNED BY public.procurement_risktype.id;


--
-- Name: procurement_salesdata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_salesdata (
    id bigint NOT NULL,
    date date NOT NULL,
    quantity_sold double precision NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.procurement_salesdata OWNER TO postgres;

--
-- Name: procurement_salesdata_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_salesdata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_salesdata_id_seq OWNER TO postgres;

--
-- Name: procurement_salesdata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_salesdata_id_seq OWNED BY public.procurement_salesdata.id;


--
-- Name: procurement_sourcingregion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_sourcingregion (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(100) NOT NULL,
    geo_coordinates character varying(100) NOT NULL
);


ALTER TABLE public.procurement_sourcingregion OWNER TO postgres;

--
-- Name: procurement_sourcingregion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_sourcingregion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_sourcingregion_id_seq OWNER TO postgres;

--
-- Name: procurement_sourcingregion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_sourcingregion_id_seq OWNED BY public.procurement_sourcingregion.id;


--
-- Name: procurement_spendtransaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_spendtransaction (
    id bigint NOT NULL,
    amount numeric(12,2) NOT NULL,
    transaction_date date NOT NULL,
    description text NOT NULL,
    invoice_number character varying(100) NOT NULL,
    category_id bigint,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_spendtransaction OWNER TO postgres;

--
-- Name: procurement_spendtransaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_spendtransaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_spendtransaction_id_seq OWNER TO postgres;

--
-- Name: procurement_spendtransaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_spendtransaction_id_seq OWNED BY public.procurement_spendtransaction.id;


--
-- Name: procurement_supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_supplier (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    contact_person character varying(100) NOT NULL,
    email character varying(254) NOT NULL,
    phone character varying(30) NOT NULL,
    address text NOT NULL,
    primary_commodity_id bigint
);


ALTER TABLE public.procurement_supplier OWNER TO postgres;

--
-- Name: procurement_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_supplier_id_seq OWNER TO postgres;

--
-- Name: procurement_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_supplier_id_seq OWNED BY public.procurement_supplier.id;


--
-- Name: procurement_suppliercertification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_suppliercertification (
    id bigint NOT NULL,
    date_obtained date NOT NULL,
    expiry_date date NOT NULL,
    status character varying(50) NOT NULL,
    certification_id bigint NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_suppliercertification OWNER TO postgres;

--
-- Name: procurement_suppliercertification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_suppliercertification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_suppliercertification_id_seq OWNER TO postgres;

--
-- Name: procurement_suppliercertification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_suppliercertification_id_seq OWNED BY public.procurement_suppliercertification.id;


--
-- Name: procurement_supplierevaluationmetric; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_supplierevaluationmetric (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.procurement_supplierevaluationmetric OWNER TO postgres;

--
-- Name: procurement_supplierevaluationmetric_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_supplierevaluationmetric_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_supplierevaluationmetric_id_seq OWNER TO postgres;

--
-- Name: procurement_supplierevaluationmetric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_supplierevaluationmetric_id_seq OWNED BY public.procurement_supplierevaluationmetric.id;


--
-- Name: procurement_supplierinteraction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_supplierinteraction (
    id bigint NOT NULL,
    interaction_type character varying(100) NOT NULL,
    date date NOT NULL,
    summary text NOT NULL,
    recorded_by_id integer,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_supplierinteraction OWNER TO postgres;

--
-- Name: procurement_supplierinteraction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_supplierinteraction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_supplierinteraction_id_seq OWNER TO postgres;

--
-- Name: procurement_supplierinteraction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_supplierinteraction_id_seq OWNED BY public.procurement_supplierinteraction.id;


--
-- Name: procurement_supplierperformance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_supplierperformance (
    id bigint NOT NULL,
    score double precision NOT NULL,
    date date NOT NULL,
    notes text NOT NULL,
    metric_id bigint NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_supplierperformance OWNER TO postgres;

--
-- Name: procurement_supplierperformance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_supplierperformance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_supplierperformance_id_seq OWNER TO postgres;

--
-- Name: procurement_supplierperformance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_supplierperformance_id_seq OWNED BY public.procurement_supplierperformance.id;


--
-- Name: procurement_supplierriskscore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_supplierriskscore (
    id bigint NOT NULL,
    score_date date NOT NULL,
    overall_score double precision NOT NULL,
    geopolitical_score double precision NOT NULL,
    climate_score double precision NOT NULL,
    status character varying(50) NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_supplierriskscore OWNER TO postgres;

--
-- Name: procurement_supplierriskscore_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_supplierriskscore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_supplierriskscore_id_seq OWNER TO postgres;

--
-- Name: procurement_supplierriskscore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_supplierriskscore_id_seq OWNED BY public.procurement_supplierriskscore.id;


--
-- Name: procurement_sustainabilitymetric; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurement_sustainabilitymetric (
    id bigint NOT NULL,
    metric_type character varying(100) NOT NULL,
    value double precision NOT NULL,
    date date NOT NULL,
    source character varying(100) NOT NULL,
    supplier_id bigint NOT NULL
);


ALTER TABLE public.procurement_sustainabilitymetric OWNER TO postgres;

--
-- Name: procurement_sustainabilitymetric_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurement_sustainabilitymetric_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurement_sustainabilitymetric_id_seq OWNER TO postgres;

--
-- Name: procurement_sustainabilitymetric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurement_sustainabilitymetric_id_seq OWNED BY public.procurement_sustainabilitymetric.id;


--
-- Name: analytics_mlmodel id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_mlmodel ALTER COLUMN id SET DEFAULT nextval('public.analytics_mlmodel_id_seq'::regclass);


--
-- Name: analytics_mlmodelresult id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_mlmodelresult ALTER COLUMN id SET DEFAULT nextval('public.analytics_mlmodelresult_id_seq'::regclass);


--
-- Name: analytics_mlmodelrun id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_mlmodelrun ALTER COLUMN id SET DEFAULT nextval('public.analytics_mlmodelrun_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: core_userprofile id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_userprofile ALTER COLUMN id SET DEFAULT nextval('public.core_userprofile_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_celery_beat_clockedschedule id; Type: DEFAULT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_clockedschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_crontabschedule id; Type: DEFAULT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_crontabschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_intervalschedule id; Type: DEFAULT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_intervalschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_periodictask id; Type: DEFAULT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_periodictask ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_periodictask_id_seq'::regclass);


--
-- Name: django_celery_beat_solarschedule id; Type: DEFAULT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_solarschedule_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: procurement_auditreport id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_auditreport ALTER COLUMN id SET DEFAULT nextval('public.procurement_auditreport_id_seq'::regclass);


--
-- Name: procurement_certification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_certification ALTER COLUMN id SET DEFAULT nextval('public.procurement_certification_id_seq'::regclass);


--
-- Name: procurement_commodity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_commodity ALTER COLUMN id SET DEFAULT nextval('public.procurement_commodity_id_seq'::regclass);


--
-- Name: procurement_commoditynews id; Type: DEFAULT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.procurement_commoditynews ALTER COLUMN id SET DEFAULT nextval('public.procurement_commoditynews_id_seq'::regclass);


--
-- Name: procurement_commodityprice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_commodityprice ALTER COLUMN id SET DEFAULT nextval('public.procurement_commodityprice_id_seq'::regclass);


--
-- Name: procurement_expensecategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_expensecategory ALTER COLUMN id SET DEFAULT nextval('public.procurement_expensecategory_id_seq'::regclass);


--
-- Name: procurement_inventorylevel id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_inventorylevel ALTER COLUMN id SET DEFAULT nextval('public.procurement_inventorylevel_id_seq'::regclass);


--
-- Name: procurement_invoice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_invoice ALTER COLUMN id SET DEFAULT nextval('public.procurement_invoice_id_seq'::regclass);


--
-- Name: procurement_materialforecast id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_materialforecast ALTER COLUMN id SET DEFAULT nextval('public.procurement_materialforecast_id_seq'::regclass);


--
-- Name: procurement_priceprediction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_priceprediction ALTER COLUMN id SET DEFAULT nextval('public.procurement_priceprediction_id_seq'::regclass);


--
-- Name: procurement_procurementnewssummary id; Type: DEFAULT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.procurement_procurementnewssummary ALTER COLUMN id SET DEFAULT nextval('public.procurement_procurementnewssummary_id_seq'::regclass);


--
-- Name: procurement_product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_product ALTER COLUMN id SET DEFAULT nextval('public.procurement_product_id_seq'::regclass);


--
-- Name: procurement_productcomponent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_productcomponent ALTER COLUMN id SET DEFAULT nextval('public.procurement_productcomponent_id_seq'::regclass);


--
-- Name: procurement_purchaseorder id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_purchaseorder ALTER COLUMN id SET DEFAULT nextval('public.procurement_purchaseorder_id_seq'::regclass);


--
-- Name: procurement_purchaseorderitem id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_purchaseorderitem ALTER COLUMN id SET DEFAULT nextval('public.procurement_purchaseorderitem_id_seq'::regclass);


--
-- Name: procurement_rawmaterial id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_rawmaterial ALTER COLUMN id SET DEFAULT nextval('public.procurement_rawmaterial_id_seq'::regclass);


--
-- Name: procurement_riskevent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent ALTER COLUMN id SET DEFAULT nextval('public.procurement_riskevent_id_seq'::regclass);


--
-- Name: procurement_riskevent_impacted_commodities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent_impacted_commodities ALTER COLUMN id SET DEFAULT nextval('public.procurement_riskevent_impacted_commodities_id_seq'::regclass);


--
-- Name: procurement_risktype id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_risktype ALTER COLUMN id SET DEFAULT nextval('public.procurement_risktype_id_seq'::regclass);


--
-- Name: procurement_salesdata id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_salesdata ALTER COLUMN id SET DEFAULT nextval('public.procurement_salesdata_id_seq'::regclass);


--
-- Name: procurement_sourcingregion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_sourcingregion ALTER COLUMN id SET DEFAULT nextval('public.procurement_sourcingregion_id_seq'::regclass);


--
-- Name: procurement_spendtransaction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_spendtransaction ALTER COLUMN id SET DEFAULT nextval('public.procurement_spendtransaction_id_seq'::regclass);


--
-- Name: procurement_supplier id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplier ALTER COLUMN id SET DEFAULT nextval('public.procurement_supplier_id_seq'::regclass);


--
-- Name: procurement_suppliercertification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_suppliercertification ALTER COLUMN id SET DEFAULT nextval('public.procurement_suppliercertification_id_seq'::regclass);


--
-- Name: procurement_supplierevaluationmetric id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierevaluationmetric ALTER COLUMN id SET DEFAULT nextval('public.procurement_supplierevaluationmetric_id_seq'::regclass);


--
-- Name: procurement_supplierinteraction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierinteraction ALTER COLUMN id SET DEFAULT nextval('public.procurement_supplierinteraction_id_seq'::regclass);


--
-- Name: procurement_supplierperformance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierperformance ALTER COLUMN id SET DEFAULT nextval('public.procurement_supplierperformance_id_seq'::regclass);


--
-- Name: procurement_supplierriskscore id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierriskscore ALTER COLUMN id SET DEFAULT nextval('public.procurement_supplierriskscore_id_seq'::regclass);


--
-- Name: procurement_sustainabilitymetric id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_sustainabilitymetric ALTER COLUMN id SET DEFAULT nextval('public.procurement_sustainabilitymetric_id_seq'::regclass);


--
-- Data for Name: analytics_mlmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_mlmodel (id, name, version, description, created_at) FROM stdin;
\.
COPY public.analytics_mlmodel (id, name, version, description, created_at) FROM '$$PATH$$/5344.dat';

--
-- Data for Name: analytics_mlmodelresult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_mlmodelresult (id, result_data, created_at, run_id) FROM stdin;
\.
COPY public.analytics_mlmodelresult (id, result_data, created_at, run_id) FROM '$$PATH$$/5346.dat';

--
-- Data for Name: analytics_mlmodelrun; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.analytics_mlmodelrun (id, run_date, parameters, status, model_id) FROM stdin;
\.
COPY public.analytics_mlmodelrun (id, run_date, parameters, status, model_id) FROM '$$PATH$$/5348.dat';

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/5350.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/5352.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/5354.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/5356.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/5357.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/5360.dat';

--
-- Data for Name: core_userprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_userprofile (id, role, user_id) FROM stdin;
\.
COPY public.core_userprofile (id, role, user_id) FROM '$$PATH$$/5362.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/5364.dat';

--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: motherparkers_user
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM stdin;
\.
COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM '$$PATH$$/5435.dat';

--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: motherparkers_user
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
\.
COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM '$$PATH$$/5426.dat';

--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: motherparkers_user
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.
COPY public.django_celery_beat_intervalschedule (id, every, period) FROM '$$PATH$$/5428.dat';

--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: motherparkers_user
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM stdin;
\.
COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM '$$PATH$$/5430.dat';

--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: motherparkers_user
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
\.
COPY public.django_celery_beat_periodictasks (ident, last_update) FROM '$$PATH$$/5431.dat';

--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: motherparkers_user
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.
COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM '$$PATH$$/5433.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/5366.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/5368.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/5370.dat';

--
-- Data for Name: procurement_auditreport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_auditreport (id, audit_date, report_summary, compliance_status, supplier_id) FROM stdin;
\.
COPY public.procurement_auditreport (id, audit_date, report_summary, compliance_status, supplier_id) FROM '$$PATH$$/5371.dat';

--
-- Data for Name: procurement_certification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_certification (id, name, description, issuing_body) FROM stdin;
\.
COPY public.procurement_certification (id, name, description, issuing_body) FROM '$$PATH$$/5373.dat';

--
-- Data for Name: procurement_commodity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_commodity (id, name, type, unit_of_measure) FROM stdin;
\.
COPY public.procurement_commodity (id, name, type, unit_of_measure) FROM '$$PATH$$/5375.dat';

--
-- Data for Name: procurement_commoditynews; Type: TABLE DATA; Schema: public; Owner: motherparkers_user
--

COPY public.procurement_commoditynews (id, article_data, fetch_date, time_range_start, time_range_end, coffee_commodity_price_fluctuation, coffee_geopolitical_tensions, coffee_logistics_delays, coffee_shipping_costs, coffee_freight_rates, coffee_natural_disasters, coffee_labor_strikes, coffee_market_shortage, coffee_procurement_fraud, coffee_supplier_risk, coffee_global_demand_shift, coffee_manufacturing_slowdown, coffee_regulatory_changes, commodity_id) FROM stdin;
\.
COPY public.procurement_commoditynews (id, article_data, fetch_date, time_range_start, time_range_end, coffee_commodity_price_fluctuation, coffee_geopolitical_tensions, coffee_logistics_delays, coffee_shipping_costs, coffee_freight_rates, coffee_natural_disasters, coffee_labor_strikes, coffee_market_shortage, coffee_procurement_fraud, coffee_supplier_risk, coffee_global_demand_shift, coffee_manufacturing_slowdown, coffee_regulatory_changes, commodity_id) FROM '$$PATH$$/5437.dat';

--
-- Data for Name: procurement_commodityprice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_commodityprice (id, date, price, source_api, currency, commodity_id) FROM stdin;
\.
COPY public.procurement_commodityprice (id, date, price, source_api, currency, commodity_id) FROM '$$PATH$$/5377.dat';

--
-- Data for Name: procurement_expensecategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_expensecategory (id, name, description, parent_category_id) FROM stdin;
\.
COPY public.procurement_expensecategory (id, name, description, parent_category_id) FROM '$$PATH$$/5379.dat';

--
-- Data for Name: procurement_inventorylevel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_inventorylevel (id, warehouse, quantity, last_updated, raw_material_id) FROM stdin;
\.
COPY public.procurement_inventorylevel (id, warehouse, quantity, last_updated, raw_material_id) FROM '$$PATH$$/5381.dat';

--
-- Data for Name: procurement_invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_invoice (id, invoice_number, total_amount, issue_date, due_date, status, po_id, supplier_id) FROM stdin;
\.
COPY public.procurement_invoice (id, invoice_number, total_amount, issue_date, due_date, status, po_id, supplier_id) FROM '$$PATH$$/5383.dat';

--
-- Data for Name: procurement_materialforecast; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_materialforecast (id, forecast_date, predicted_demand_qty, model_version, raw_material_id) FROM stdin;
\.
COPY public.procurement_materialforecast (id, forecast_date, predicted_demand_qty, model_version, raw_material_id) FROM '$$PATH$$/5385.dat';

--
-- Data for Name: procurement_priceprediction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_priceprediction (id, prediction_date, predicted_price, model_version, confidence_score, commodity_id) FROM stdin;
\.
COPY public.procurement_priceprediction (id, prediction_date, predicted_price, model_version, confidence_score, commodity_id) FROM '$$PATH$$/5387.dat';

--
-- Data for Name: procurement_procurementnewssummary; Type: TABLE DATA; Schema: public; Owner: motherparkers_user
--

COPY public.procurement_procurementnewssummary (id, created_at, result_json) FROM stdin;
\.
COPY public.procurement_procurementnewssummary (id, created_at, result_json) FROM '$$PATH$$/5439.dat';

--
-- Data for Name: procurement_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_product (id, name, sku, unit_of_sale) FROM stdin;
\.
COPY public.procurement_product (id, name, sku, unit_of_sale) FROM '$$PATH$$/5389.dat';

--
-- Data for Name: procurement_productcomponent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_productcomponent (id, quantity_needed, product_id, raw_material_id) FROM stdin;
\.
COPY public.procurement_productcomponent (id, quantity_needed, product_id, raw_material_id) FROM '$$PATH$$/5391.dat';

--
-- Data for Name: procurement_purchaseorder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_purchaseorder (id, po_number, total_amount, order_date, status, currency, supplier_id) FROM stdin;
\.
COPY public.procurement_purchaseorder (id, po_number, total_amount, order_date, status, currency, supplier_id) FROM '$$PATH$$/5393.dat';

--
-- Data for Name: procurement_purchaseorderitem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_purchaseorderitem (id, quantity, unit_price, line_total, po_id, raw_material_id) FROM stdin;
\.
COPY public.procurement_purchaseorderitem (id, quantity, unit_price, line_total, po_id, raw_material_id) FROM '$$PATH$$/5395.dat';

--
-- Data for Name: procurement_rawmaterial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_rawmaterial (id, name, unit_of_measure, min_stock_level, max_stock_level) FROM stdin;
\.
COPY public.procurement_rawmaterial (id, name, unit_of_measure, min_stock_level, max_stock_level) FROM '$$PATH$$/5397.dat';

--
-- Data for Name: procurement_riskevent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_riskevent (id, description, severity, status, event_date, source_data, region_id, risk_type_id) FROM stdin;
\.
COPY public.procurement_riskevent (id, description, severity, status, event_date, source_data, region_id, risk_type_id) FROM '$$PATH$$/5399.dat';

--
-- Data for Name: procurement_riskevent_impacted_commodities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_riskevent_impacted_commodities (id, riskevent_id, commodity_id) FROM stdin;
\.
COPY public.procurement_riskevent_impacted_commodities (id, riskevent_id, commodity_id) FROM '$$PATH$$/5401.dat';

--
-- Data for Name: procurement_risktype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_risktype (id, name, description) FROM stdin;
\.
COPY public.procurement_risktype (id, name, description) FROM '$$PATH$$/5403.dat';

--
-- Data for Name: procurement_salesdata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_salesdata (id, date, quantity_sold, product_id) FROM stdin;
\.
COPY public.procurement_salesdata (id, date, quantity_sold, product_id) FROM '$$PATH$$/5405.dat';

--
-- Data for Name: procurement_sourcingregion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_sourcingregion (id, name, country, geo_coordinates) FROM stdin;
\.
COPY public.procurement_sourcingregion (id, name, country, geo_coordinates) FROM '$$PATH$$/5407.dat';

--
-- Data for Name: procurement_spendtransaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_spendtransaction (id, amount, transaction_date, description, invoice_number, category_id, supplier_id) FROM stdin;
\.
COPY public.procurement_spendtransaction (id, amount, transaction_date, description, invoice_number, category_id, supplier_id) FROM '$$PATH$$/5409.dat';

--
-- Data for Name: procurement_supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_supplier (id, name, contact_person, email, phone, address, primary_commodity_id) FROM stdin;
\.
COPY public.procurement_supplier (id, name, contact_person, email, phone, address, primary_commodity_id) FROM '$$PATH$$/5411.dat';

--
-- Data for Name: procurement_suppliercertification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_suppliercertification (id, date_obtained, expiry_date, status, certification_id, supplier_id) FROM stdin;
\.
COPY public.procurement_suppliercertification (id, date_obtained, expiry_date, status, certification_id, supplier_id) FROM '$$PATH$$/5413.dat';

--
-- Data for Name: procurement_supplierevaluationmetric; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_supplierevaluationmetric (id, name, description) FROM stdin;
\.
COPY public.procurement_supplierevaluationmetric (id, name, description) FROM '$$PATH$$/5415.dat';

--
-- Data for Name: procurement_supplierinteraction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_supplierinteraction (id, interaction_type, date, summary, recorded_by_id, supplier_id) FROM stdin;
\.
COPY public.procurement_supplierinteraction (id, interaction_type, date, summary, recorded_by_id, supplier_id) FROM '$$PATH$$/5417.dat';

--
-- Data for Name: procurement_supplierperformance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_supplierperformance (id, score, date, notes, metric_id, supplier_id) FROM stdin;
\.
COPY public.procurement_supplierperformance (id, score, date, notes, metric_id, supplier_id) FROM '$$PATH$$/5419.dat';

--
-- Data for Name: procurement_supplierriskscore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_supplierriskscore (id, score_date, overall_score, geopolitical_score, climate_score, status, supplier_id) FROM stdin;
\.
COPY public.procurement_supplierriskscore (id, score_date, overall_score, geopolitical_score, climate_score, status, supplier_id) FROM '$$PATH$$/5421.dat';

--
-- Data for Name: procurement_sustainabilitymetric; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurement_sustainabilitymetric (id, metric_type, value, date, source, supplier_id) FROM stdin;
\.
COPY public.procurement_sustainabilitymetric (id, metric_type, value, date, source, supplier_id) FROM '$$PATH$$/5423.dat';

--
-- Name: analytics_mlmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_mlmodel_id_seq', 1, false);


--
-- Name: analytics_mlmodelresult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_mlmodelresult_id_seq', 1, false);


--
-- Name: analytics_mlmodelrun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.analytics_mlmodelrun_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 176, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 4, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: core_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_userprofile_id_seq', 3, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: motherparkers_user
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: motherparkers_user
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 1, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: motherparkers_user
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: motherparkers_user
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 1, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: motherparkers_user
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 44, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 45, true);


--
-- Name: procurement_auditreport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_auditreport_id_seq', 1, false);


--
-- Name: procurement_certification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_certification_id_seq', 1, false);


--
-- Name: procurement_commodity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_commodity_id_seq', 2, true);


--
-- Name: procurement_commoditynews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: motherparkers_user
--

SELECT pg_catalog.setval('public.procurement_commoditynews_id_seq', 250, true);


--
-- Name: procurement_commodityprice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_commodityprice_id_seq', 10, true);


--
-- Name: procurement_expensecategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_expensecategory_id_seq', 1, false);


--
-- Name: procurement_inventorylevel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_inventorylevel_id_seq', 1, false);


--
-- Name: procurement_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_invoice_id_seq', 1, false);


--
-- Name: procurement_materialforecast_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_materialforecast_id_seq', 1, false);


--
-- Name: procurement_priceprediction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_priceprediction_id_seq', 1, false);


--
-- Name: procurement_procurementnewssummary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: motherparkers_user
--

SELECT pg_catalog.setval('public.procurement_procurementnewssummary_id_seq', 5, true);


--
-- Name: procurement_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_product_id_seq', 1, false);


--
-- Name: procurement_productcomponent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_productcomponent_id_seq', 1, false);


--
-- Name: procurement_purchaseorder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_purchaseorder_id_seq', 1, false);


--
-- Name: procurement_purchaseorderitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_purchaseorderitem_id_seq', 1, false);


--
-- Name: procurement_rawmaterial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_rawmaterial_id_seq', 1, false);


--
-- Name: procurement_riskevent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_riskevent_id_seq', 1, false);


--
-- Name: procurement_riskevent_impacted_commodities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_riskevent_impacted_commodities_id_seq', 1, false);


--
-- Name: procurement_risktype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_risktype_id_seq', 1, false);


--
-- Name: procurement_salesdata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_salesdata_id_seq', 1, false);


--
-- Name: procurement_sourcingregion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_sourcingregion_id_seq', 1, false);


--
-- Name: procurement_spendtransaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_spendtransaction_id_seq', 1, false);


--
-- Name: procurement_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_supplier_id_seq', 1, false);


--
-- Name: procurement_suppliercertification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_suppliercertification_id_seq', 1, false);


--
-- Name: procurement_supplierevaluationmetric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_supplierevaluationmetric_id_seq', 1, false);


--
-- Name: procurement_supplierinteraction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_supplierinteraction_id_seq', 1, false);


--
-- Name: procurement_supplierperformance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_supplierperformance_id_seq', 1, false);


--
-- Name: procurement_supplierriskscore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_supplierriskscore_id_seq', 1, false);


--
-- Name: procurement_sustainabilitymetric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurement_sustainabilitymetric_id_seq', 1, false);


--
-- Name: analytics_mlmodel analytics_mlmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_mlmodel
    ADD CONSTRAINT analytics_mlmodel_pkey PRIMARY KEY (id);


--
-- Name: analytics_mlmodelresult analytics_mlmodelresult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_mlmodelresult
    ADD CONSTRAINT analytics_mlmodelresult_pkey PRIMARY KEY (id);


--
-- Name: analytics_mlmodelrun analytics_mlmodelrun_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_mlmodelrun
    ADD CONSTRAINT analytics_mlmodelrun_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: core_userprofile core_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_userprofile
    ADD CONSTRAINT core_userprofile_pkey PRIMARY KEY (id);


--
-- Name: core_userprofile core_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_userprofile
    ADD CONSTRAINT core_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_clockedschedule django_celery_beat_clockedschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule
    ADD CONSTRAINT django_celery_beat_clockedschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_crontabschedule django_celery_beat_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule
    ADD CONSTRAINT django_celery_beat_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_intervalschedule django_celery_beat_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule
    ADD CONSTRAINT django_celery_beat_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_name_key UNIQUE (name);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictasks django_celery_beat_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_periodictasks
    ADD CONSTRAINT django_celery_beat_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq UNIQUE (event, latitude, longitude);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solarschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solarschedule_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: procurement_auditreport procurement_auditreport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_auditreport
    ADD CONSTRAINT procurement_auditreport_pkey PRIMARY KEY (id);


--
-- Name: procurement_certification procurement_certification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_certification
    ADD CONSTRAINT procurement_certification_pkey PRIMARY KEY (id);


--
-- Name: procurement_commodity procurement_commodity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_commodity
    ADD CONSTRAINT procurement_commodity_pkey PRIMARY KEY (id);


--
-- Name: procurement_commoditynews procurement_commoditynews_pkey; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.procurement_commoditynews
    ADD CONSTRAINT procurement_commoditynews_pkey PRIMARY KEY (id);


--
-- Name: procurement_commodityprice procurement_commodityprice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_commodityprice
    ADD CONSTRAINT procurement_commodityprice_pkey PRIMARY KEY (id);


--
-- Name: procurement_expensecategory procurement_expensecategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_expensecategory
    ADD CONSTRAINT procurement_expensecategory_pkey PRIMARY KEY (id);


--
-- Name: procurement_inventorylevel procurement_inventorylevel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_inventorylevel
    ADD CONSTRAINT procurement_inventorylevel_pkey PRIMARY KEY (id);


--
-- Name: procurement_invoice procurement_invoice_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_invoice
    ADD CONSTRAINT procurement_invoice_invoice_number_key UNIQUE (invoice_number);


--
-- Name: procurement_invoice procurement_invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_invoice
    ADD CONSTRAINT procurement_invoice_pkey PRIMARY KEY (id);


--
-- Name: procurement_materialforecast procurement_materialforecast_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_materialforecast
    ADD CONSTRAINT procurement_materialforecast_pkey PRIMARY KEY (id);


--
-- Name: procurement_priceprediction procurement_priceprediction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_priceprediction
    ADD CONSTRAINT procurement_priceprediction_pkey PRIMARY KEY (id);


--
-- Name: procurement_procurementnewssummary procurement_procurementnewssummary_pkey; Type: CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.procurement_procurementnewssummary
    ADD CONSTRAINT procurement_procurementnewssummary_pkey PRIMARY KEY (id);


--
-- Name: procurement_product procurement_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_product
    ADD CONSTRAINT procurement_product_pkey PRIMARY KEY (id);


--
-- Name: procurement_productcomponent procurement_productcomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_productcomponent
    ADD CONSTRAINT procurement_productcomponent_pkey PRIMARY KEY (id);


--
-- Name: procurement_purchaseorder procurement_purchaseorder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_purchaseorder
    ADD CONSTRAINT procurement_purchaseorder_pkey PRIMARY KEY (id);


--
-- Name: procurement_purchaseorder procurement_purchaseorder_po_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_purchaseorder
    ADD CONSTRAINT procurement_purchaseorder_po_number_key UNIQUE (po_number);


--
-- Name: procurement_purchaseorderitem procurement_purchaseorderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_purchaseorderitem
    ADD CONSTRAINT procurement_purchaseorderitem_pkey PRIMARY KEY (id);


--
-- Name: procurement_rawmaterial procurement_rawmaterial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_rawmaterial
    ADD CONSTRAINT procurement_rawmaterial_pkey PRIMARY KEY (id);


--
-- Name: procurement_riskevent_impacted_commodities procurement_riskevent_im_riskevent_id_commodity_i_d8ca315e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent_impacted_commodities
    ADD CONSTRAINT procurement_riskevent_im_riskevent_id_commodity_i_d8ca315e_uniq UNIQUE (riskevent_id, commodity_id);


--
-- Name: procurement_riskevent_impacted_commodities procurement_riskevent_impacted_commodities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent_impacted_commodities
    ADD CONSTRAINT procurement_riskevent_impacted_commodities_pkey PRIMARY KEY (id);


--
-- Name: procurement_riskevent procurement_riskevent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent
    ADD CONSTRAINT procurement_riskevent_pkey PRIMARY KEY (id);


--
-- Name: procurement_risktype procurement_risktype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_risktype
    ADD CONSTRAINT procurement_risktype_pkey PRIMARY KEY (id);


--
-- Name: procurement_salesdata procurement_salesdata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_salesdata
    ADD CONSTRAINT procurement_salesdata_pkey PRIMARY KEY (id);


--
-- Name: procurement_sourcingregion procurement_sourcingregion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_sourcingregion
    ADD CONSTRAINT procurement_sourcingregion_pkey PRIMARY KEY (id);


--
-- Name: procurement_spendtransaction procurement_spendtransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_spendtransaction
    ADD CONSTRAINT procurement_spendtransaction_pkey PRIMARY KEY (id);


--
-- Name: procurement_supplier procurement_supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplier
    ADD CONSTRAINT procurement_supplier_pkey PRIMARY KEY (id);


--
-- Name: procurement_suppliercertification procurement_suppliercertification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_suppliercertification
    ADD CONSTRAINT procurement_suppliercertification_pkey PRIMARY KEY (id);


--
-- Name: procurement_supplierevaluationmetric procurement_supplierevaluationmetric_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierevaluationmetric
    ADD CONSTRAINT procurement_supplierevaluationmetric_pkey PRIMARY KEY (id);


--
-- Name: procurement_supplierinteraction procurement_supplierinteraction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierinteraction
    ADD CONSTRAINT procurement_supplierinteraction_pkey PRIMARY KEY (id);


--
-- Name: procurement_supplierperformance procurement_supplierperformance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierperformance
    ADD CONSTRAINT procurement_supplierperformance_pkey PRIMARY KEY (id);


--
-- Name: procurement_supplierriskscore procurement_supplierriskscore_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierriskscore
    ADD CONSTRAINT procurement_supplierriskscore_pkey PRIMARY KEY (id);


--
-- Name: procurement_sustainabilitymetric procurement_sustainabilitymetric_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_sustainabilitymetric
    ADD CONSTRAINT procurement_sustainabilitymetric_pkey PRIMARY KEY (id);


--
-- Name: analytics_mlmodelresult_run_id_80c5b5f6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_mlmodelresult_run_id_80c5b5f6 ON public.analytics_mlmodelresult USING btree (run_id);


--
-- Name: analytics_mlmodelrun_model_id_ff0aa3f1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX analytics_mlmodelrun_model_id_ff0aa3f1 ON public.analytics_mlmodelrun USING btree (model_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_celery_beat_periodictask_clocked_id_47a69f82; Type: INDEX; Schema: public; Owner: motherparkers_user
--

CREATE INDEX django_celery_beat_periodictask_clocked_id_47a69f82 ON public.django_celery_beat_periodictask USING btree (clocked_id);


--
-- Name: django_celery_beat_periodictask_crontab_id_d3cba168; Type: INDEX; Schema: public; Owner: motherparkers_user
--

CREATE INDEX django_celery_beat_periodictask_crontab_id_d3cba168 ON public.django_celery_beat_periodictask USING btree (crontab_id);


--
-- Name: django_celery_beat_periodictask_interval_id_a8ca27da; Type: INDEX; Schema: public; Owner: motherparkers_user
--

CREATE INDEX django_celery_beat_periodictask_interval_id_a8ca27da ON public.django_celery_beat_periodictask USING btree (interval_id);


--
-- Name: django_celery_beat_periodictask_name_265a36b7_like; Type: INDEX; Schema: public; Owner: motherparkers_user
--

CREATE INDEX django_celery_beat_periodictask_name_265a36b7_like ON public.django_celery_beat_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: django_celery_beat_periodictask_solar_id_a87ce72c; Type: INDEX; Schema: public; Owner: motherparkers_user
--

CREATE INDEX django_celery_beat_periodictask_solar_id_a87ce72c ON public.django_celery_beat_periodictask USING btree (solar_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: procurement_auditreport_supplier_id_7ac23ce0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_auditreport_supplier_id_7ac23ce0 ON public.procurement_auditreport USING btree (supplier_id);


--
-- Name: procurement_commodi_8f8a7f_idx; Type: INDEX; Schema: public; Owner: motherparkers_user
--

CREATE INDEX procurement_commodi_8f8a7f_idx ON public.procurement_commoditynews USING btree (commodity_id);


--
-- Name: procurement_commoditynews_commodity_id_3cc668d3; Type: INDEX; Schema: public; Owner: motherparkers_user
--

CREATE INDEX procurement_commoditynews_commodity_id_3cc668d3 ON public.procurement_commoditynews USING btree (commodity_id);


--
-- Name: procurement_commodityprice_commodity_id_702363a4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_commodityprice_commodity_id_702363a4 ON public.procurement_commodityprice USING btree (commodity_id);


--
-- Name: procurement_created_6c248e_idx; Type: INDEX; Schema: public; Owner: motherparkers_user
--

CREATE INDEX procurement_created_6c248e_idx ON public.procurement_procurementnewssummary USING btree (created_at);


--
-- Name: procurement_expensecategory_parent_category_id_390e5c7c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_expensecategory_parent_category_id_390e5c7c ON public.procurement_expensecategory USING btree (parent_category_id);


--
-- Name: procurement_inventorylevel_raw_material_id_6d61e0cb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_inventorylevel_raw_material_id_6d61e0cb ON public.procurement_inventorylevel USING btree (raw_material_id);


--
-- Name: procurement_invoice_invoice_number_717934e3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_invoice_invoice_number_717934e3_like ON public.procurement_invoice USING btree (invoice_number varchar_pattern_ops);


--
-- Name: procurement_invoice_po_id_9ae900ff; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_invoice_po_id_9ae900ff ON public.procurement_invoice USING btree (po_id);


--
-- Name: procurement_invoice_supplier_id_f9f6938e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_invoice_supplier_id_f9f6938e ON public.procurement_invoice USING btree (supplier_id);


--
-- Name: procurement_materialforecast_raw_material_id_f89a2e3d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_materialforecast_raw_material_id_f89a2e3d ON public.procurement_materialforecast USING btree (raw_material_id);


--
-- Name: procurement_priceprediction_commodity_id_1e88d4f4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_priceprediction_commodity_id_1e88d4f4 ON public.procurement_priceprediction USING btree (commodity_id);


--
-- Name: procurement_productcomponent_product_id_e19d5ad2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_productcomponent_product_id_e19d5ad2 ON public.procurement_productcomponent USING btree (product_id);


--
-- Name: procurement_productcomponent_raw_material_id_b9122e01; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_productcomponent_raw_material_id_b9122e01 ON public.procurement_productcomponent USING btree (raw_material_id);


--
-- Name: procurement_purchaseorder_po_number_4ea69920_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_purchaseorder_po_number_4ea69920_like ON public.procurement_purchaseorder USING btree (po_number varchar_pattern_ops);


--
-- Name: procurement_purchaseorder_supplier_id_119eb9cd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_purchaseorder_supplier_id_119eb9cd ON public.procurement_purchaseorder USING btree (supplier_id);


--
-- Name: procurement_purchaseorderitem_po_id_96416403; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_purchaseorderitem_po_id_96416403 ON public.procurement_purchaseorderitem USING btree (po_id);


--
-- Name: procurement_purchaseorderitem_raw_material_id_2ae8f8d2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_purchaseorderitem_raw_material_id_2ae8f8d2 ON public.procurement_purchaseorderitem USING btree (raw_material_id);


--
-- Name: procurement_riskevent_impa_commodity_id_49469318; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_riskevent_impa_commodity_id_49469318 ON public.procurement_riskevent_impacted_commodities USING btree (commodity_id);


--
-- Name: procurement_riskevent_impa_riskevent_id_37c3b256; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_riskevent_impa_riskevent_id_37c3b256 ON public.procurement_riskevent_impacted_commodities USING btree (riskevent_id);


--
-- Name: procurement_riskevent_region_id_64b30767; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_riskevent_region_id_64b30767 ON public.procurement_riskevent USING btree (region_id);


--
-- Name: procurement_riskevent_risk_type_id_84c8170a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_riskevent_risk_type_id_84c8170a ON public.procurement_riskevent USING btree (risk_type_id);


--
-- Name: procurement_salesdata_product_id_456c0cf1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_salesdata_product_id_456c0cf1 ON public.procurement_salesdata USING btree (product_id);


--
-- Name: procurement_spendtransaction_category_id_1a810ea0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_spendtransaction_category_id_1a810ea0 ON public.procurement_spendtransaction USING btree (category_id);


--
-- Name: procurement_spendtransaction_supplier_id_d22adc08; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_spendtransaction_supplier_id_d22adc08 ON public.procurement_spendtransaction USING btree (supplier_id);


--
-- Name: procurement_supplier_primary_commodity_id_bef75262; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_supplier_primary_commodity_id_bef75262 ON public.procurement_supplier USING btree (primary_commodity_id);


--
-- Name: procurement_suppliercertification_certification_id_98874b92; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_suppliercertification_certification_id_98874b92 ON public.procurement_suppliercertification USING btree (certification_id);


--
-- Name: procurement_suppliercertification_supplier_id_593900d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_suppliercertification_supplier_id_593900d9 ON public.procurement_suppliercertification USING btree (supplier_id);


--
-- Name: procurement_supplierinteraction_recorded_by_id_2b244cb7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_supplierinteraction_recorded_by_id_2b244cb7 ON public.procurement_supplierinteraction USING btree (recorded_by_id);


--
-- Name: procurement_supplierinteraction_supplier_id_0b4210e3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_supplierinteraction_supplier_id_0b4210e3 ON public.procurement_supplierinteraction USING btree (supplier_id);


--
-- Name: procurement_supplierperformance_metric_id_41892572; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_supplierperformance_metric_id_41892572 ON public.procurement_supplierperformance USING btree (metric_id);


--
-- Name: procurement_supplierperformance_supplier_id_a766098c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_supplierperformance_supplier_id_a766098c ON public.procurement_supplierperformance USING btree (supplier_id);


--
-- Name: procurement_supplierriskscore_supplier_id_d843de3e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_supplierriskscore_supplier_id_d843de3e ON public.procurement_supplierriskscore USING btree (supplier_id);


--
-- Name: procurement_sustainabilitymetric_supplier_id_47e78f53; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX procurement_sustainabilitymetric_supplier_id_47e78f53 ON public.procurement_sustainabilitymetric USING btree (supplier_id);


--
-- Name: analytics_mlmodelresult analytics_mlmodelres_run_id_80c5b5f6_fk_analytics; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_mlmodelresult
    ADD CONSTRAINT analytics_mlmodelres_run_id_80c5b5f6_fk_analytics FOREIGN KEY (run_id) REFERENCES public.analytics_mlmodelrun(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: analytics_mlmodelrun analytics_mlmodelrun_model_id_ff0aa3f1_fk_analytics_mlmodel_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.analytics_mlmodelrun
    ADD CONSTRAINT analytics_mlmodelrun_model_id_ff0aa3f1_fk_analytics_mlmodel_id FOREIGN KEY (model_id) REFERENCES public.analytics_mlmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_userprofile core_userprofile_user_id_5141ad90_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_userprofile
    ADD CONSTRAINT core_userprofile_user_id_5141ad90_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_clocked_id_47a69f82_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_clocked_id_47a69f82_fk_django_ce FOREIGN KEY (clocked_id) REFERENCES public.django_celery_beat_clockedschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_crontab_id_d3cba168_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_crontab_id_d3cba168_fk_django_ce FOREIGN KEY (crontab_id) REFERENCES public.django_celery_beat_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_interval_id_a8ca27da_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_interval_id_a8ca27da_fk_django_ce FOREIGN KEY (interval_id) REFERENCES public.django_celery_beat_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_solar_id_a87ce72c_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_solar_id_a87ce72c_fk_django_ce FOREIGN KEY (solar_id) REFERENCES public.django_celery_beat_solarschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_auditreport procurement_auditrep_supplier_id_7ac23ce0_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_auditreport
    ADD CONSTRAINT procurement_auditrep_supplier_id_7ac23ce0_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_commoditynews procurement_commodit_commodity_id_3cc668d3_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: motherparkers_user
--

ALTER TABLE ONLY public.procurement_commoditynews
    ADD CONSTRAINT procurement_commodit_commodity_id_3cc668d3_fk_procureme FOREIGN KEY (commodity_id) REFERENCES public.procurement_commodity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_commodityprice procurement_commodit_commodity_id_702363a4_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_commodityprice
    ADD CONSTRAINT procurement_commodit_commodity_id_702363a4_fk_procureme FOREIGN KEY (commodity_id) REFERENCES public.procurement_commodity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_expensecategory procurement_expensec_parent_category_id_390e5c7c_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_expensecategory
    ADD CONSTRAINT procurement_expensec_parent_category_id_390e5c7c_fk_procureme FOREIGN KEY (parent_category_id) REFERENCES public.procurement_expensecategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_inventorylevel procurement_inventor_raw_material_id_6d61e0cb_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_inventorylevel
    ADD CONSTRAINT procurement_inventor_raw_material_id_6d61e0cb_fk_procureme FOREIGN KEY (raw_material_id) REFERENCES public.procurement_rawmaterial(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_invoice procurement_invoice_po_id_9ae900ff_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_invoice
    ADD CONSTRAINT procurement_invoice_po_id_9ae900ff_fk_procureme FOREIGN KEY (po_id) REFERENCES public.procurement_purchaseorder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_invoice procurement_invoice_supplier_id_f9f6938e_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_invoice
    ADD CONSTRAINT procurement_invoice_supplier_id_f9f6938e_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_materialforecast procurement_material_raw_material_id_f89a2e3d_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_materialforecast
    ADD CONSTRAINT procurement_material_raw_material_id_f89a2e3d_fk_procureme FOREIGN KEY (raw_material_id) REFERENCES public.procurement_rawmaterial(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_priceprediction procurement_pricepre_commodity_id_1e88d4f4_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_priceprediction
    ADD CONSTRAINT procurement_pricepre_commodity_id_1e88d4f4_fk_procureme FOREIGN KEY (commodity_id) REFERENCES public.procurement_commodity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_productcomponent procurement_productc_product_id_e19d5ad2_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_productcomponent
    ADD CONSTRAINT procurement_productc_product_id_e19d5ad2_fk_procureme FOREIGN KEY (product_id) REFERENCES public.procurement_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_productcomponent procurement_productc_raw_material_id_b9122e01_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_productcomponent
    ADD CONSTRAINT procurement_productc_raw_material_id_b9122e01_fk_procureme FOREIGN KEY (raw_material_id) REFERENCES public.procurement_rawmaterial(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_purchaseorderitem procurement_purchase_po_id_96416403_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_purchaseorderitem
    ADD CONSTRAINT procurement_purchase_po_id_96416403_fk_procureme FOREIGN KEY (po_id) REFERENCES public.procurement_purchaseorder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_purchaseorderitem procurement_purchase_raw_material_id_2ae8f8d2_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_purchaseorderitem
    ADD CONSTRAINT procurement_purchase_raw_material_id_2ae8f8d2_fk_procureme FOREIGN KEY (raw_material_id) REFERENCES public.procurement_rawmaterial(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_purchaseorder procurement_purchase_supplier_id_119eb9cd_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_purchaseorder
    ADD CONSTRAINT procurement_purchase_supplier_id_119eb9cd_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_riskevent_impacted_commodities procurement_riskeven_commodity_id_49469318_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent_impacted_commodities
    ADD CONSTRAINT procurement_riskeven_commodity_id_49469318_fk_procureme FOREIGN KEY (commodity_id) REFERENCES public.procurement_commodity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_riskevent procurement_riskeven_region_id_64b30767_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent
    ADD CONSTRAINT procurement_riskeven_region_id_64b30767_fk_procureme FOREIGN KEY (region_id) REFERENCES public.procurement_sourcingregion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_riskevent procurement_riskeven_risk_type_id_84c8170a_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent
    ADD CONSTRAINT procurement_riskeven_risk_type_id_84c8170a_fk_procureme FOREIGN KEY (risk_type_id) REFERENCES public.procurement_risktype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_riskevent_impacted_commodities procurement_riskeven_riskevent_id_37c3b256_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_riskevent_impacted_commodities
    ADD CONSTRAINT procurement_riskeven_riskevent_id_37c3b256_fk_procureme FOREIGN KEY (riskevent_id) REFERENCES public.procurement_riskevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_salesdata procurement_salesdat_product_id_456c0cf1_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_salesdata
    ADD CONSTRAINT procurement_salesdat_product_id_456c0cf1_fk_procureme FOREIGN KEY (product_id) REFERENCES public.procurement_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_spendtransaction procurement_spendtra_category_id_1a810ea0_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_spendtransaction
    ADD CONSTRAINT procurement_spendtra_category_id_1a810ea0_fk_procureme FOREIGN KEY (category_id) REFERENCES public.procurement_expensecategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_spendtransaction procurement_spendtra_supplier_id_d22adc08_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_spendtransaction
    ADD CONSTRAINT procurement_spendtra_supplier_id_d22adc08_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_suppliercertification procurement_supplier_certification_id_98874b92_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_suppliercertification
    ADD CONSTRAINT procurement_supplier_certification_id_98874b92_fk_procureme FOREIGN KEY (certification_id) REFERENCES public.procurement_certification(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_supplierperformance procurement_supplier_metric_id_41892572_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierperformance
    ADD CONSTRAINT procurement_supplier_metric_id_41892572_fk_procureme FOREIGN KEY (metric_id) REFERENCES public.procurement_supplierevaluationmetric(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_supplier procurement_supplier_primary_commodity_id_bef75262_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplier
    ADD CONSTRAINT procurement_supplier_primary_commodity_id_bef75262_fk_procureme FOREIGN KEY (primary_commodity_id) REFERENCES public.procurement_commodity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_supplierinteraction procurement_supplier_recorded_by_id_2b244cb7_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierinteraction
    ADD CONSTRAINT procurement_supplier_recorded_by_id_2b244cb7_fk_auth_user FOREIGN KEY (recorded_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_supplierinteraction procurement_supplier_supplier_id_0b4210e3_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierinteraction
    ADD CONSTRAINT procurement_supplier_supplier_id_0b4210e3_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_suppliercertification procurement_supplier_supplier_id_593900d9_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_suppliercertification
    ADD CONSTRAINT procurement_supplier_supplier_id_593900d9_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_supplierperformance procurement_supplier_supplier_id_a766098c_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierperformance
    ADD CONSTRAINT procurement_supplier_supplier_id_a766098c_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_supplierriskscore procurement_supplier_supplier_id_d843de3e_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_supplierriskscore
    ADD CONSTRAINT procurement_supplier_supplier_id_d843de3e_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: procurement_sustainabilitymetric procurement_sustaina_supplier_id_47e78f53_fk_procureme; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurement_sustainabilitymetric
    ADD CONSTRAINT procurement_sustaina_supplier_id_47e78f53_fk_procureme FOREIGN KEY (supplier_id) REFERENCES public.procurement_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

